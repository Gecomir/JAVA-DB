package com.example.bookshop.domain.services.authorServices;

import com.example.bookshop.domain.entities.Author;

public interface AuthorService {
    Author getRandomAuthor();
}
