package com.example.bookshop.domain.enums;

public enum AgeRestriction {
    MINOR, TEEN, ADULT
}
