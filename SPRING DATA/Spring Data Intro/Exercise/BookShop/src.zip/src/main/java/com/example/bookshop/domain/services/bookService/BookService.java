package com.example.bookshop.domain.services.bookService;

public interface BookService {}
